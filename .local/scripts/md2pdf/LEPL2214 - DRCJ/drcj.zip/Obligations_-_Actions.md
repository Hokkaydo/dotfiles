---
title: Obligations - Actions
author: Hokkaydo
geometry: left=1cm,right=1cm,top=2cm,bottom=2cm
papersize: a4
titlepage-rule-color: 00407A
date: \today
toc: false
toc-depth: 1
titlepage: true
template: eisvogel
subtitle:
output: pdf_document
---

[[CM2 - Comment convaincre un investisseur]]

Les obligations sont une sorte de crowdfunding

Une action permet 2 choses :
- Vendre l'action
- Voter pour les choix de l'entreprise
Mais un actionnaire pourrait vouloir se désister de son droit de vote car il n'a aucune compétence pour voter intelligemment. 
=> Quelqu'un qui cherche des investisseurs préfère que ses actionnaires abandonnent leur droit de vote, pour ça il peut donner des dividendes préférentiels pour ceux qui s'en désistent.
