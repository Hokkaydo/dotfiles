---
title: Cas Lego
author: Hokkaydo
geometry: left=1cm,right=1cm,top=2cm,bottom=2cm
papersize: a4
titlepage-rule-color: 00407A
date: \today
toc: false
toc-depth: 1
titlepage: false
template: eisvogel
subtitle:
output: pdf_document
---

---
name: Cas Lego
aliases: 
tags:
  - lepl2214
---
from [[CM3 - Droits de propriété intellectuelle]]

LEGO a initialement protégé son produit par un brevet mais celui-ci dure 20. Donc en 1968, ils en ont repris un pour "perfectionnement" jusqu'en 1988. 
A ce moment là, ils ont voulu faire passer le fait que la brique LEGO est une marque. Mais ça n'a pas marché car "Une forme édictée par des considérations techniques ne peut pas être enregistrée comme une marque". Cela signifie que la brique qui a été créée pour s'emboîter avec les autres n'étaient pas une marque.

LEGO a alors breveté des tonnes de choses faites à bases de LEGO : clé USB, clé, cafetière, chocolat, ...