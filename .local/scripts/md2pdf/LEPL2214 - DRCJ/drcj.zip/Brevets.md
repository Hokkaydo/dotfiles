---
title: Brevets
author: Hokkaydo
geometry: left=1cm,right=1cm,top=2cm,bottom=2cm
papersize: a4
titlepage-rule-color: 00407A
date: \today
toc: false
toc-depth: 1
titlepage: false
template: eisvogel
subtitle:
output: pdf_document
---

#lepl2214 
[[CM4 - Brevets|CM4 - Brevets]]
1. Le brevet protège une invention 
	= Une création technique = une création sous contrainte technique qui vise à solutionner un problème précis.
2. Le brevet est un droit d'exclure
	= il donne un droit exclusif sur toute utilisation commerciale d'une invention = permet d'exclure les concurrents d'un marché déterminé. Le brevet n'est pas un droit d'exploiter (on peut exploiter son invention avec ou sans brevet)
3. Objectif du brevet: encourager l'investissement dans la R&D
4. [[Brevet vs. Droit d'auteur vs Marque vs Dessins et modèles]]
5. [[Invention]]