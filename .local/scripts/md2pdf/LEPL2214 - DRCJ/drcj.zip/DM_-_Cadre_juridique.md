---
title: DM - Cadre juridique
author: Hokkaydo
geometry: left=1cm,right=1cm,top=2cm,bottom=2cm
papersize: a4
titlepage-rule-color: 00407A
date: \today
toc: false
toc-depth: 1
titlepage: false
template: eisvogel
subtitle:
output: pdf_document
---

#lepl2214 [[CM7 - Droit des marques]]

On peut demander une marque à 3 niveaux différents : 
- Marque Benelux
- Marque U.E.
- Marque internationale 