---
title: CM7 - Droit des marques
author: Hokkaydo
geometry: left=1cm,right=1cm,top=2cm,bottom=2cm
papersize: a4
titlepage-rule-color: 00407A
date: \today
toc: false
toc-depth: 1
titlepage: false
template: eisvogel
subtitle:
output: pdf_document
---

#lepl2214 [[LEPL2214 - DRCJ]]

1. [[DM - Cadre juridique]]
2. [[DM - Objet de la protection]]
3. [[DM - Conditions de la protection]]
4. [[DM - Droits conférés par la marque]]
