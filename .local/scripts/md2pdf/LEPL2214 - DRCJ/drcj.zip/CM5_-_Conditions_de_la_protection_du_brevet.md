---
title: CM5 - Conditions de la protection du brevet
author: Hokkaydo
geometry: left=1cm,right=1cm,top=2cm,bottom=2cm
papersize: a4
titlepage-rule-color: 00407A
date: \today
toc: false
toc-depth: 1
titlepage: false
template: eisvogel
subtitle:
output: pdf_document
---
 [[LEPL2214 - DRCJ]] #lepl2214 

Il existe 4 conditions primordiales : 
- [[Invention]]
- [[Exigence de nouveauté]]
- [[Implication d'une activité inventive]]
- [[Application industrielle]]

Il existe beaucoup de domaines exclus du champ de la brevetabilité.
Par exemple si l'invention pourrait avoir une application industrielle néfaste (virus qui tue les plantes par ex), c'est contraire à l'ordre public et aux bonnes mœurs.
En revanche, les armes sont brevetables.  Elles ne posent pas de souci car c'est encadré par la loi.

[[Réflexion Travail 1]]

