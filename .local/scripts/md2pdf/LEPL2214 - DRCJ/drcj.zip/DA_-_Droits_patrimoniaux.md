---
title: DA - Droits patrimoniaux
author: Hokkaydo
geometry: left=1cm,right=1cm,top=2cm,bottom=2cm
papersize: a4
titlepage-rule-color: 00407A
date: \today
toc: false
toc-depth: 1
titlepage: false
template: eisvogel
subtitle:
output: pdf_document
---

[[CM6 - Fin brevet & Droits d'auteur (CM7)]]
#lepl2214 
1. Droits de reproductions
	Ne pas copier, modifier, adapter, traduire
	=> Très large, toute reproduction, même toute partie de l'œuvre protégée est couverte
	/!\ Pas d'atteinte si pas de reproduction : création indépendante
	En général, quand 2 œuvres se ressemblent, on considère que la plus récente est une reproduction de la plus ancienne SAUF si le second auteur peut prouver qu'il ne pouvait pas connaître la première œuvre -> créations indépendantes
2. Droit de prêt (gratuit) ou de location (payant)
3. Droit de distribution
	Contrôle de la vente (mais pas des revente, ne fonctionne qu'à la première vente)
	Contrôle des dons, mise en circulation des exemplaires de l'œuvre
4. Droit de communication au public
	Radiodiffusion, transmissions par câble ou satellite
