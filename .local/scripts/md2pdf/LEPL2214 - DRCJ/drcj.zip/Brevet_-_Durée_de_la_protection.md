---
title: Brevet - Durée de la protection
author: Hokkaydo
geometry: left=1cm,right=1cm,top=2cm,bottom=2cm
papersize: a4
titlepage-rule-color: 00407A
date: \today
toc: false
toc-depth: 1
titlepage: false
template: eisvogel
subtitle:
output: pdf_document
---

[[CM6 - Fin brevet & Droits d'auteur (CM7)]]
#lepl2214 

Le brevet est un titre national valable pour une période limitée sur un territoire limité

=> 20 ans partir de la date de dépôt (si les annuités sont payées)